require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const plans = [
  { id: "free", name: "Free", priceEth: "0", requests: 10 },
  { id: "pro", name: "Pro", priceEth: "0.001", requests: 500 },
  { id: "power", name: "Power", priceEth: "0.003", requests: 2000 }
];

app.get("/api/config", (req, res) => {
  res.json({
    appName: process.env.APP_NAME || "NovaAI",
    network: process.env.ETH_NETWORK || "sepolia",
    receivingAddress: process.env.ETH_RECEIVING_ADDRESS || "",
    testnetOnly: true
  });
});

app.get("/api/plans", (req, res) => res.json(plans));

app.post("/api/ai", (req, res) => {
  const prompt = String(req.body.prompt || "").trim();
  if (!prompt) return res.status(400).json({ error: "Enter a prompt." });

  // Demo response. Replace this endpoint with your chosen AI provider later.
  res.json({
    answer:
      "Demo AI response:\\n\\n" +
      `You asked: ${prompt}\\n\\n` +
      "Connect your AI provider in this server endpoint to make NovaAI fully functional."
  });
});

app.post("/api/payment/verify", (req, res) => {
  const { txHash, planId } = req.body;
  if (!txHash || !planId) {
    return res.status(400).json({ ok: false, error: "Transaction hash and plan are required." });
  }

  // IMPORTANT: This demo does NOT verify blockchain transactions.
  // For production, use a trusted blockchain provider and server-side verification.
  res.json({
    ok: true,
    demo: true,
    message: "Demo transaction received. No real ETH was processed or verified.",
    txHash,
    planId
  });
});

app.get("*splat", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`NovaAI running at http://localhost:${PORT}`);
});