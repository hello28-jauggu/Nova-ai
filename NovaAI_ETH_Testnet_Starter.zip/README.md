# NovaAI — AI + ETH Testnet Demo

## Features
- AI workspace UI
- Pricing plans
- ETH payment section
- Sepolia/testnet-only configuration
- Node.js + Express backend
- Mobile-friendly frontend

## Run in GitHub Codespaces / local
```bash
npm install
cp .env.example .env
npm start
```

Open port 3000.

## Important
This project intentionally does NOT process or verify real ETH.
For a production service, payment verification must happen server-side using a reputable blockchain RPC/indexing provider, and access should only be granted after independently verifying the transaction.

Never put a wallet private key, seed phrase, or secret recovery phrase in this project.
