let config, plans=[];

const $ = id => document.getElementById(id);

async function load() {
  config = await fetch("/api/config").then(r=>r.json());
  plans = await fetch("/api/plans").then(r=>r.json());

  $("network").textContent = config.network;
  $("address").textContent = config.receivingAddress || "Set ETH_RECEIVING_ADDRESS in .env";

  $("plans").innerHTML = plans.map(p => `
    <div>
      <h3>${p.name}</h3>
      <div class="price">${p.priceEth} ETH</div>
      <p class="muted">${p.requests} AI requests</p>
      <button class="btn" onclick="choosePlan('${p.id}')">Choose</button>
    </div>`).join("");

  $("planSelect").innerHTML = plans.map(p =>
    `<option value="${p.id}">${p.name} — ${p.priceEth} ETH</option>`).join("");

  updateAmount();
}

function choosePlan(id) {
  $("planSelect").value = id;
  updateAmount();
  location.hash = "payment";
}

function updateAmount() {
  const p = plans.find(x => x.id === $("planSelect").value);
  if (p) $("amount").textContent = p.priceEth + " ETH";
}

$("planSelect").addEventListener("change", updateAmount);

$("askBtn").addEventListener("click", async () => {
  const prompt = $("prompt").value.trim();
  if (!prompt) return;
  $("answer").textContent = "Thinking...";
  const r = await fetch("/api/ai", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({prompt})
  });
  const data = await r.json();
  $("answer").textContent = data.answer || data.error;
});

$("verifyBtn").addEventListener("click", async () => {
  const txHash = $("txHash").value.trim();
  const planId = $("planSelect").value;
  if (!txHash) return $("paymentStatus").textContent = "Enter a testnet transaction hash.";

  const r = await fetch("/api/payment/verify", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({txHash, planId})
  });
  const data = await r.json();
  $("paymentStatus").textContent = data.message || data.error;
});

load();